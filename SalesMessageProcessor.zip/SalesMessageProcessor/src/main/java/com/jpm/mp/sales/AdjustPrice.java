package com.jpm.mp.sales;

/**
 * Performs Operations on price based on the input
 *
 */
public class AdjustPrice {

	private double adjustedPrice;

	private Product product;

	public AdjustPrice(Product product) {
		this.product = product;
		this.adjustedPrice = 0.0;
	}

	public double getAdjustedPrice() {
		
		if(product.getAdjustmentOperator().equalsIgnoreCase("add")){
			addPrice();
		}else if (product.getAdjustmentOperator().equalsIgnoreCase("subtract")){
			subtractPrice();
		}else if (product.getAdjustmentOperator().equalsIgnoreCase("multiply")){
			multiplyPrice();
		}
		return adjustedPrice;
	}

	public void addPrice() {
		this.adjustedPrice = this.product.getTotalPrice()
				+ (this.product.getTotalQuantity() * this.product.getProductPrice());
	}

	public void subtractPrice() {
		this.adjustedPrice = this.product.getTotalPrice()
				- (this.product.getTotalQuantity() * this.product.getProductPrice());
	}

	public void multiplyPrice() {
		this.adjustedPrice = this.product.getTotalPrice()
				+ (this.product.getTotalPrice() * this.product.getProductPrice())
				+ (this.product.getTotalQuantity() * this.product.getProductPrice());
	}

	public String prepFinalReport() {
		String adjReport = this.product.getAdjustmentOperator()+" "+this.product.getProductPrice()
							+ "p to "+this.product.getTotalQuantity()+" "+this.product.getProductType()
							+" and price adjusted from "+this.product.getTotalPrice()+" to "+this.adjustedPrice;
		return adjReport;
	}

}
