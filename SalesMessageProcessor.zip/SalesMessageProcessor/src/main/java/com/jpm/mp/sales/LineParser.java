package com.jpm.mp.sales;

/**
 * Parse the input msg and dIfferentiate the 3 incoming messages and store the details 
 *
 */
public class LineParser {
	private String productType;
	private double productCost;
	private int productQty;
	private String adjOperator;

	public LineParser(String line) {
		this.productType = "";
		this.productCost = 0.0;
		this.productQty = 0;
		this.adjOperator = "";
		parseEachLine(line);
	}

	private boolean parseEachLine(String line) {

		if (null == line || line.isEmpty()) {
			return false;
		}
		String[] arr = line.trim().split(" ");
		String startWord = arr[0];
		if (startWord.matches("Add|Subtract|Multiply")) {
			return parseSaleAdj3rdLine(arr);
		} else if (arr.length == 7) {
			return parse2ndLine(arr);
		} else if (arr.length == 3) {
			return parseProductType1stLine(arr);
		} else {
			System.out.println("Invalid Notification recieved and the notification is "+ line);
		}
		return true;
	}

	private boolean parseProductType1stLine(String[] lineArr) {
		productType = lineArr[0];
		productCost = parsePrice(lineArr[2]);
		productQty = 1; 
		return true;
	}

	private boolean parse2ndLine(String[] lineArr) {
		productType = lineArr[3];
		productCost = parsePrice(lineArr[5]);
		productQty = Integer.parseInt(lineArr[0]);
		return true;
	}

	private boolean parseSaleAdj3rdLine(String[] lineArr) {
		if (lineArr.length != 3)
			return false;
		adjOperator = lineArr[0];
		productType = lineArr[2];
		productQty = 0;
		productCost = parsePrice(lineArr[1]);
		return true;
	}


	public double parsePrice(String rawPrice) {
		double price = Double.parseDouble(rawPrice.replace("p", ""));
		if (!rawPrice.contains(".")) {
			price = Double.valueOf(Double.valueOf(price) / Double.valueOf("100"));
		}
		return price;
	}

	public String getProductType() {
		return productType;
	}

	public double getProductPrice() {
		return productCost;
	}

	public String getOperatorType() {
		return adjOperator;
	}

	public int getProductQuantity() {
		return productQty;
	}


}
