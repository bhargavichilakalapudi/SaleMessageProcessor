package com.jpm.mp.sales;

public class Sales {

	DisplaySaleData displaySaleData;
	private AdjustPrice adjustPrice;
	private Product product;
	public Sales() {
		displaySaleData	= new DisplaySaleData();	}

	public boolean processInputSalesMessage(String line) {

		LineParser lineParser = new LineParser(line);

		String productType = lineParser.getProductType();

		if (productType.isEmpty()) {
			return false;
		}

		this.product = displaySaleData.getProduct(productType);

		this.adjustPrice = new AdjustPrice(product);

		this.product.setProductQuantity(lineParser.getProductQuantity());
		this.product.setTotalQuantity(lineParser.getProductQuantity());
		this.product.setProductPrice(lineParser.getProductPrice());
		this.product.setAdjustmentOperator(lineParser.getOperatorType());

		setProductTotalPrice();

		displaySaleData.setNormalReports(line);

		displaySaleData.updateProduct(product);

		return true;
	}

	private void setProductTotalPrice() {
		double adjustedPrice;
		double productValue;

		if (!product.getAdjustmentOperator().isEmpty()) {
			adjustedPrice = adjustPrice.getAdjustedPrice();
			displaySaleData.setAdjustmentReports(adjustPrice.prepFinalReport());
			product.setTotalPrice(adjustedPrice);
		} else {
			productValue = product.calculatePrice(product.getProductQuantity(), product.getProductPrice());
			product.appendTotalPrice(productValue);
		}
	}
}
