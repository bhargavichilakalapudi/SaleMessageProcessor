package com.jpm.mp.sales;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;

/**
 * Receives the sales notifications and process it and displays it
 *
 */
public class SalesMsgProcessor {

	public static void main(String args[]) throws IOException{
		Sales sales= new Sales();
		String fileName = "";
		if(null != args && args.length == 1){
			fileName = args[0];
		}else{
			fileName = "salesInput.txt";
		}
		BufferedReader br = readInputFile(fileName);

		String line;
		while ((line = br.readLine()) != null) {
			sales.processInputSalesMessage(line);

			sales.displaySaleData.buildReport();
		}

	}

	public static BufferedReader readInputFile(String fileName) throws FileNotFoundException {
		URL resource = ClassLoader.getSystemResource(fileName);
		File file = new File(resource.getFile());
		FileReader reader = new FileReader(file);
		BufferedReader br = new BufferedReader(reader);
		return br;
	}
}
