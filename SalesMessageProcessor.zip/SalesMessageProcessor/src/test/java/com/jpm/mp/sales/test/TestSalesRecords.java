package com.jpm.mp.sales.test;

import java.io.IOException;

import org.junit.Test;

import com.jpm.mp.sales.SalesMsgProcessor;

public class TestSalesRecords {
	
	@Test
	public void readSalesMessage() throws IOException{
		SalesMsgProcessor.main(new String[] {"salesInput.txt"});
	}

}
